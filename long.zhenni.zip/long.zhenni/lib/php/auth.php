<?php


function MYSQLIAuth() {
	return[
       "localhost", // Database host location
       "zlong_wmn608", // Database user name
       "Liushasha712", // Database user password
       "zlong_wnm608" // Database databse name
	];
}
