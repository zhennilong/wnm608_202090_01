<?php


function MYSQLIAuth() {
	return[
       "", // Database host location
       "", // Database user name
       "", // Database user password
       "" // Database databse name
	]
}
