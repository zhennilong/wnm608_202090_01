# Zhenni Long

## Important Links

 
- http://zhennilong.com/aau/wnm608/long.zhenni/index.php

- http://zhennilong.com/aau/wnm608/long.zhenni/styleguide/styleguide.html



## Other Links

- http://zhennilong.com/aau/wnm608/long.zhenni/recipes/index.html
- http://zhennilong.com/aau/wnm608/long.zhenni/landingpage.html



