<?php 
   include_once "lib/php/functions.php";
include_once "parts/templates.php";
include_once "data/api.php"; ?>

<?php include "parts/meta.php" ?>

<div id="promo-window" class="container" >
        
        <div class="grid display-flex promo">
            <div class="col-xl-6 col-xs-12 article flex-stretch promo-text">
                <div class="promo-text gaps" >
                    <h2>the science of soft</h2>
                     <p>we craft the softest organic fabrics for a gentle calming effect

                     </p>
                </div>
            </div>
            <div class="col-xl-6 col-xs-12 flex-stretch display-flex flex-align-center flex-justify-center">
                    <img src="img/store/toy-bear-other.jpg" alt="sleeping baby">
            </div>
        </div>

         <div class="grid display-flex promo margin-up-down">
            
            <div class="col-xl-6 col-xs-12 flex-stretch display-flex flex-align-center flex-justify-center">
                    <img src="img/store/toy-bunny-main.jpg" alt="sleeping baby">
            </div>
            <div class="col-xl-6 col-xs-12 article flex-stretch promo-text">
                <div class="promo-text gaps" >
                    <h2>the science of soft</h2>
                     <p>we craft the softest organic fabrics for a gentle calming effect

                     </p>
                </div>
            </div>
        </div>
</div>