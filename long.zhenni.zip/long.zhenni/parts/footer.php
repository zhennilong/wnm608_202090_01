<?php 
   include_once "lib/php/functions.php";
include_once "parts/templates.php";
include_once "data/api.php"; ?>

<?php include "parts/meta.php" ?>



<footer class="footer-margin background-blue">
	
         <div class="grid footer-padding" >
            <div class="col-md-4 col-xs-12">
                <div class="footer">
                    <ul>
                        <li>About Us</li>
                        <li>FAQ</li>
                        
                    </ul>
                </div>
            </div>  

            <div class="col-md-4 col-xs-12">
                <div class="footer ">
                        <ul>
                            <li>Shipping & Return</li>
                            <li>Refer a Friend</li>
                            
                        </ul>
                </div>
            </div>
            
      
            <div class="col-md-4 col-xs-12">
                <div class="footer ">
                    <ul>
                        <li>Privacy Poilicy</li>
                        <li>Terms & Conditions</li>
                    </ul>
                </div>
            </div>


     
          <!--   <div class="col-md-6 col-xs-12">
                <div class="footer">
                    
                    <div>Join our newsletter to receive 10% off your first order!</div>

                    <form>
                        <div >
                            
                            <input id="example-1" type="text" placeholder="Your Email Address" class="form-input-box-white">
                        </div>
                    </form>
                   
               </div>
                
            </div> -->
         </div>
 
	

</footer>