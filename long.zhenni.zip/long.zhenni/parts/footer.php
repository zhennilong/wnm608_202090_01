<?php 
   include_once "lib/php/functions.php";
include_once "parts/templates.php";
include_once "data/api.php"; ?>

<?php include "parts/meta.php" ?>
<footer class="footer-margin background-blue">
	
         <div class="grid footer-padding" >
            <div class="col-md-3 col-xs-12">
                <div class="footer">
                    <ul>
                        <li>About Us</li>
                        <li>Contact Us</li>
                        <li>Shipping & Return</li>
                    </ul>
                </div>
            </div> 
            <div class="col-md-3 col-xs-12">
                <div class="footer ">
                    <ul>
                        <li>Privacy Poilicy</li>
                        <li>Terms & Conditions</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-xs-12">
                <div class="footer">
                    
                    <div>Join our newsletter to receive 10% off your first order!</div>

                    <form>
                        <div >
                            
                            <input id="example-1" type="text" placeholder="Your Email Address" class="form-input-box-white">
                        </div>
                    </form>
                     <!--   <a href="index.php"> 
             <img src="img/logo.png" alt="logo" width="200px" style="
        margin: 10px auto;"> 
                   </a> -->
               </div>
                
            </div>
         </div>
 
	

</footer>